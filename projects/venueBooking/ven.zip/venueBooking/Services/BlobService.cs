using Azure.Storage.Blobs;

namespace venueBooking.Services
{
    public class BlobService
    {
        private readonly BlobContainerClient _container;

        public BlobService(IConfiguration config)
        {
            var conn = config["AzureBlob:ConnectionString"];
            var name = config["AzureBlob:ContainerName"];
            _container = new BlobContainerClient(conn, name);
            _container.CreateIfNotExists();
        }
        //0d7d3b76-a11a-469e-8b95-d3de167e2990

        public async Task<string> UploadAsync(IFormFile file)
        {
            var blob = _container.GetBlobClient(Guid.NewGuid() + Path.GetExtension(file.FileName));
            await using var stream = file.OpenReadStream();
            await blob.UploadAsync(stream);
            return blob.Uri.ToString();
        }
    }
}