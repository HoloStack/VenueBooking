using System;
using System.ComponentModel.DataAnnotations;

namespace venueBooking.Models
{
    public class Event
    {
        public int EventId { get; set; }

        [Required]
        public string EventName { get; set; }

        [Required]
        [DataType(DataType.DateTime)]
        // Force the editor template to use yyyy-MM-ddTHH:mm
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-ddTHH:mm}", ApplyFormatInEditMode = true)]
        public DateTime EventDate { get; set; }

        public string Description { get; set; }
        public int VenueId { get; set; }
        public int EventTypeId { get; set; }
        public virtual Venue Venue { get; set; }
        public virtual EventType EventType { get; set; }
    }
}