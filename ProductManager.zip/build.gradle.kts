// Top-level build file where you can add configuration options common to all sub-projects/modules.
//plugins {
//    // Apply plugin aliases from version catalog
//    alias(libs.plugins.android.application) apply false
//    alias(libs.plugins.kotlin.android) apply false
//    alias(libs.plugins.kotlin.compose) apply false
//}
plugins {
    // We declare application-wide plugins here but not apply them yet
    id("com.android.application") apply false
    kotlin("android") apply false
    id("com.google.gms.google-services") apply false
}