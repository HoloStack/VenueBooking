using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using venueBooking.Data;
using venueBooking.Models;
using venueBooking.Services;

namespace venueBooking.Controllers
{
    public class VenuesController : Controller
    {
        private readonly ApplicationDbContext _db;
        private readonly BlobService _blobService;

        public VenuesController(ApplicationDbContext db, BlobService blobService)
        {
            _db = db;
            _blobService = blobService;
        }

        // GET: Venues with filter by event type and availability
        public async Task<IActionResult> Index(int? eventTypeId, DateTime? fromDate, DateTime? toDate)
        {
            var query = _db.Venues
                .Include(v => v.SupportedEventTypes)
                .Include(v => v.Events)
                .AsQueryable();

            // filter by supported event type
            if (eventTypeId.HasValue)
                query = query.Where(v => v.SupportedEventTypes.Any(et => et.EventTypeId == eventTypeId.Value));

            // filter by availability (no events in date range)
            if (fromDate.HasValue)
                query = query.Where(v => !v.Events
                    .Any(e => e.EventDate.Date >= fromDate.Value.Date
                              && (!toDate.HasValue || e.EventDate.Date <= toDate.Value.Date)));

            ViewBag.EventTypesFilter = new SelectList(
                await _db.EventTypes.ToListAsync(), "EventTypeId", "Name", eventTypeId);
            ViewBag.FromDate = fromDate?.ToString("yyyy-MM-dd");
            ViewBag.ToDate = toDate?.ToString("yyyy-MM-dd");

            var venues = await query.ToListAsync();
            return View(venues);
        }

        // GET: Venues/Create
        public IActionResult Create()
        {
            ViewBag.EventTypes = new MultiSelectList(_db.EventTypes, "EventTypeId", "Name");
            return View();
        }

        // POST: Venues/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Venue venue, IFormFile image, int[] EventTypeIds)
        {
            if (image != null && image.Length > 0)
                venue.ImageUrl = await _blobService.UploadAsync(image);

            venue.SupportedEventTypes = await _db.EventTypes
                .Where(et => EventTypeIds.Contains(et.EventTypeId))
                .ToListAsync();

            if (!ModelState.IsValid)
            {
                ViewBag.EventTypes = new MultiSelectList(_db.EventTypes, "EventTypeId", "Name", EventTypeIds);
                return View(venue);
            }

            _db.Venues.Add(venue);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: Venues/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();
            var venue = await _db.Venues
                .Include(v => v.SupportedEventTypes)
                .FirstOrDefaultAsync(v => v.VenueId == id);
            if (venue == null) return NotFound();

            ViewBag.EventTypes = new MultiSelectList(
                _db.EventTypes, "EventTypeId", "Name",
                venue.SupportedEventTypes.Select(et => et.EventTypeId));
            return View(venue);
        }

        // POST: Venues/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Venue venue, IFormFile image, int[] EventTypeIds)
        {
            if (id != venue.VenueId) return NotFound();
            if (image != null && image.Length > 0)
                venue.ImageUrl = await _blobService.UploadAsync(image);

            venue.SupportedEventTypes = await _db.EventTypes
                .Where(et => EventTypeIds.Contains(et.EventTypeId))
                .ToListAsync();

            if (!ModelState.IsValid)
            {
                ViewBag.EventTypes = new MultiSelectList(_db.EventTypes, "EventTypeId", "Name", EventTypeIds);
                return View(venue);
            }

            _db.Venues.Update(venue);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}