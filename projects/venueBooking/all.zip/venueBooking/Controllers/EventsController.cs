
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using venueBooking.Data;
using venueBooking.Models;
using venueBooking.Services;
using System;
using System.Threading.Tasks;

namespace venueBooking.Controllers
{
    public class EventsController : Controller
    {
        private readonly ApplicationDbContext _db;
        private readonly BlobService _blobService;
        public EventsController(ApplicationDbContext db, BlobService blobService)
        {
            _db = db;
            _blobService = blobService;
        }

        // GET: Ev    ents
        public async Task<IActionResult> Index()
        {
            var events = await _db.Events
                .Include(e => e.Venue)
                .Include(e => e.EventType)
                .ToListAsync();
            return View(events);
        }

        // GET: Events/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var evt = await _db.Events
                .Include(e => e.Venue)
                .Include(e => e.EventType)
                .FirstOrDefaultAsync(e => e.EventId == id);
            if (evt == null) return NotFound();

            return View(evt);
        }

        // GET: Events/Create
        public async Task<IActionResult> Create()
        {
            // Populate dropdown lists
            ViewBag.Venues = new SelectList(await _db.Venues.ToListAsync(), "VenueId", "VenueName");
            ViewBag.EventTypes = new SelectList(await _db.EventTypes.ToListAsync(), "EventTypeId", "Name");
            return View();
        }

        // POST: Events/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Event evt, IFormFile image)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Venues = new SelectList(await _db.Venues.ToListAsync(), "VenueId", "VenueName", evt.VenueId);
                ViewBag.EventTypes = new SelectList(await _db.EventTypes.ToListAsync(), "EventTypeId", "Name", evt.EventTypeId);
                return View(evt);
            }

            // Handle image upload
            if (image != null && image.Length > 0)
            {
                evt.ImageUrl = await _blobService.UploadAsync(image);
            }

            _db.Events.Add(evt);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: Events/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var evt = await _db.Events.FindAsync(id);
            if (evt == null) return NotFound();

            ViewBag.Venues = new SelectList(await _db.Venues.ToListAsync(), "VenueId", "VenueName", evt.VenueId);
            ViewBag.EventTypes = new SelectList(await _db.EventTypes.ToListAsync(), "EventTypeId", "Name", evt.EventTypeId);
            return View(evt);
        }

        // POST: Events/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Event evt, IFormFile image)
        {
            if (id != evt.EventId) return NotFound();

            if (!ModelState.IsValid)
            {
                ViewBag.Venues = new SelectList(await _db.Venues.ToListAsync(), "VenueId", "VenueName", evt.VenueId);
                ViewBag.EventTypes = new SelectList(await _db.EventTypes.ToListAsync(), "EventTypeId", "Name", evt.EventTypeId);
                return View(evt);
            }

            try
            {
                if (image != null && image.Length > 0)
                {
                    evt.ImageUrl = await _blobService.UploadAsync(image);
                }

                _db.Events.Update(evt);
                await _db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!await _db.Events.AnyAsync(e => e.EventId == id)) return NotFound();
                throw;
            }
            return RedirectToAction(nameof(Index));
        }

        // GET: Events/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var evt = await _db.Events
                .Include(e => e.Venue)
                .Include(e => e.EventType)
                .FirstOrDefaultAsync(e => e.EventId == id);
            if (evt == null) return NotFound();

            return View(evt);
        }

        // POST: Events/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var evt = await _db.Events.FindAsync(id);
            if (evt != null)
            {
                _db.Events.Remove(evt);
                await _db.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        private async Task<bool> EventExists(int id)
        {
            return await _db.Events.AnyAsync(e => e.EventId == id);
        }
    }
}